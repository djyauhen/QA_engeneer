(() => {
  const $ = (selector, context = document) => context.querySelector(selector);
  const $$ = (selector, context = document) => [...context.querySelectorAll(selector)];

  const MINUTE_MS = 60 * 1000;
  const MINUTES_IN_HOUR = 60;
  const MINUTES_IN_DAY = 24 * MINUTES_IN_HOUR;
  const SCROLL_OFFSET_PX = 60;
  const MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  const pad = value => String(value).padStart(2, "0");
  const plural = (count, word) => `${count} ${word}${count === 1 ? "" : "s"}`;

  const storage = {
    get(key) {
      try {
        return localStorage.getItem(key);
      } catch {
        return null;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, value);
        return true;
      } catch {
        return false;
      }
    }
  };

  const formatDate = date => `${MONTHS[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;

  const formatters = {
    short: minutes => {
      if (minutes < 1) return "just now";
      if (minutes < MINUTES_IN_HOUR) return `${minutes} min`;
      if (minutes < MINUTES_IN_DAY) return plural(Math.floor(minutes / MINUTES_IN_HOUR), "hr");
      return plural(Math.floor(minutes / MINUTES_IN_DAY), "day");
    },
    long: minutes => {
      if (minutes < 1) return "just now";
      if (minutes < MINUTES_IN_HOUR) return `${plural(minutes, "minute")} ago`;
      if (minutes < MINUTES_IN_DAY) return `${plural(Math.floor(minutes / MINUTES_IN_HOUR), "hour")} ago`;
      return `${plural(Math.floor(minutes / MINUTES_IN_DAY), "day")} ago`;
    },
    date: (_, date) => formatDate(date),
    published: (_, date) => {
      const hours = date.getHours();
      return `${formatDate(date)}, ${hours % 12 || 12}:${pad(date.getMinutes())} ${hours < 12 ? "AM" : "PM"}`;
    }
  };

  const renderTimes = (root = document) => {
    const now = Date.now();
    $$("[data-ago]", root).forEach(el => {
      const format = formatters[el.dataset.format];
      if (!format) return;
      const minutes = Math.max(0, Number(el.dataset.ago) || 0);
      const date = new Date(now - minutes * MINUTE_MS);
      el.textContent = format(minutes, date);
      if (el instanceof HTMLTimeElement) el.dateTime = date.toISOString();
    });
    $$(".currentYear", root).forEach(el => {
      el.textContent = new Date(now).getFullYear();
    });
  };

  const TIMER_KEY = `timer_${location.pathname}`;
  const TIMER_UNITS = ["days", "hours", "minutes", "seconds"];

  const getEndTime = () => {
    const saved = Number(storage.get(TIMER_KEY));
    if (saved > Date.now()) return saved;
    const end = new Date();
    end.setHours(24, 0, 0, 0);
    storage.set(TIMER_KEY, end.getTime());
    return end.getTime();
  };

  const initCountdown = () => {
    const digits = TIMER_UNITS.map(unit => [0, 1].map(index => $(`#cd-${unit}-${index}`)));
    if (!digits.flat().some(Boolean)) return;
    let endTime = getEndTime();

    const tick = () => {
      if (endTime <= Date.now()) endTime = getEndTime();
      const totalSeconds = Math.floor((endTime - Date.now()) / 1000);
      const values = [
        Math.floor(totalSeconds / 86400),
        Math.floor(totalSeconds / 3600) % 24,
        Math.floor(totalSeconds / 60) % 60,
        totalSeconds % 60
      ];
      digits.forEach((boxes, unitIndex) => {
        const text = pad(values[unitIndex]);
        boxes.forEach((box, index) => {
          if (box) box.textContent = text[index];
        });
      });
    };

    tick();
    setInterval(tick, 1000);
  };

  const COMMENT_KEY = `comment_${location.pathname}`;
  const COMMENT_TEMPLATE = `
    <div class="_ohe">
      <a class="img _8o _8s UFIImageBlockImage"><img class="_1ci img" src="{{cdn}}/images/no-user-img.webp" alt="" loading="lazy" decoding="async"></a>
    </div>
    <div class="UFIImageBlockContent _42ef clearfix">
      <a class="UFICommentActorName"></a>
      <div class="_3-8m _30o4 _5mdd _1n4g"></div>
      <div class="_2vq9 fsm fwn fcg">
        <a class="_4qba">Like</a> <span> · </span>
        <a class="_4qba">Reply</a> <span> · </span>
        <span>0</span> <span> · </span>
        <a class="uiLinkSubtle livetimestamp" data-format="short"></a>
      </div>
    </div>`;

  const readComment = () => {
    try {
      const data = JSON.parse(storage.get(COMMENT_KEY));
      const isValid = data && typeof data.name === "string" && typeof data.text === "string" && data.name && data.text;
      return isValid ? data : null;
    } catch {
      return null;
    }
  };

  const createComment = ({ name, text, time }) => {
    const comment = document.createElement("div");
    comment.className = "_3-8y _5nz1 clearfix";
    comment.innerHTML = COMMENT_TEMPLATE;
    $(".UFICommentActorName", comment).textContent = name;
    $("._3-8m", comment).textContent = text;
    $(".livetimestamp", comment).dataset.ago = Math.floor((Date.now() - (Number(time) || Date.now())) / MINUTE_MS);
    renderTimes(comment);
    return comment;
  };

  const showComment = (form, data) => {
    const container = $("#commentsContainer");
    const counter = $("#comments-count");
    if (container) container.prepend(createComment(data));
    if (counter) counter.textContent = (Number(counter.textContent) || 0) + 1;
    form.hidden = true;
  };

  const initCommentForm = () => {
    const form = $("#comments_form");
    const nameInput = $("#textboxname");
    const textInput = $("#textboxtext");
    const button = $("#sendcomment-btn");
    if (!form || !nameInput || !textInput || !button) return;

    const saved = readComment();
    if (saved) {
      showComment(form, saved);
      return;
    }

    const fields = [nameInput, textInput];
    const isFilled = input => input.value.trim().length > 0;
    const isReady = () => fields.every(isFilled);
    const updateButton = () => button.setAttribute("aria-disabled", String(!isReady()));

    const submit = () => {
      fields.forEach(input => input.classList.toggle("is-invalid", !isFilled(input)));
      if (!isReady()) return;
      const data = { name: nameInput.value.trim(), text: textInput.value.trim(), time: Date.now() };
      storage.set(COMMENT_KEY, JSON.stringify(data));
      showComment(form, data);
    };

    form.addEventListener("input", ({ target }) => {
      if (!fields.includes(target)) return;
      if (isFilled(target)) target.classList.remove("is-invalid");
      updateButton();
    });
    form.addEventListener("focusout", ({ target }) => {
      if (fields.includes(target)) target.classList.toggle("is-invalid", !isFilled(target));
    });
    button.addEventListener("click", submit);
    form.addEventListener("keydown", event => {
      const isButtonKey = event.target === button && (event.key === "Enter" || event.key === " ");
      const isFieldEnter = fields.includes(event.target) && event.key === "Enter";
      if (!isButtonKey && !isFieldEnter) return;
      event.preventDefault();
      submit();
    });

    updateButton();
  };

  const MAX_SCROLL_CORRECTIONS = 2;
  const SCROLL_TOLERANCE_PX = 2;
  const USER_SCROLL_EVENTS = ["wheel", "touchstart", "keydown"];

  const scrollToTarget = target => {
    const distance = () => target.getBoundingClientRect().top - SCROLL_OFFSET_PX;
    const isSmooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const go = () => window.scrollTo({ top: window.scrollY + distance(), behavior: isSmooth ? "smooth" : "auto" });
    if (Math.abs(distance()) <= SCROLL_TOLERANCE_PX) return;
    if (!isSmooth) {
      go();
      return;
    }

    let corrections = MAX_SCROLL_CORRECTIONS;
    const stopCorrections = () => {
      corrections = 0;
    };
    const cleanup = () => {
      window.removeEventListener("scrollend", onScrollEnd);
      USER_SCROLL_EVENTS.forEach(name => window.removeEventListener(name, stopCorrections));
    };
    const onScrollEnd = () => {
      if (corrections > 0 && Math.abs(distance()) > SCROLL_TOLERANCE_PX) {
        corrections -= 1;
        go();
        return;
      }
      cleanup();
    };

    window.addEventListener("scrollend", onScrollEnd);
    USER_SCROLL_EVENTS.forEach(name => window.addEventListener(name, stopCorrections, { passive: true }));
    go();
  };

  const initScrollLinks = () => {
    document.addEventListener("click", event => {
      const link = event.target.closest("a[href$='#Send-Us-Message']");
      const target = link && $("#Send-Us-Message");
      if (!target) return;
      event.preventDefault();
      scrollToTarget(target);
    });
  };

  const initStickyNav = () => {
    const nav = $("#main-nav");
    if (!nav) return;
    const wrapper = nav.parentElement;
    const STICKY_CLASSES = ["fixed-nav", "fixed-pinned", "default-behavior-mode"];
    let navTop = 0;

    const measure = () => {
      const isFixed = nav.classList.contains("fixed-nav");
      if (isFixed) nav.classList.remove(...STICKY_CLASSES);
      navTop = nav.getBoundingClientRect().top + window.scrollY;
      wrapper.style.height = `${nav.offsetHeight}px`;
      if (isFixed) nav.classList.add(...STICKY_CLASSES);
    };
    const update = () => {
      const shouldStick = window.scrollY > navTop;
      STICKY_CLASSES.forEach(name => nav.classList.toggle(name, shouldStick));
    };
    const refresh = () => {
      measure();
      update();
    };

    refresh();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", refresh);
    window.addEventListener("load", refresh);
  };

  const initCarousels = () => {
    const BREAKPOINT_MOBILE = 768;
    const BREAKPOINT_TABLET = 1024;
    const SWIPE_THRESHOLD_PX = 50;

    $$(".custom-carousel").forEach(carousel => {
      const track = $(".carousel-track", carousel);
      const slides = track ? $$(".carousel-slide-new", track) : [];
      if (!slides.length) return;

      const readCount = (name, fallback) => parseInt(carousel.dataset[name], 10) || fallback;
      const counts = {
        desktop: readCount("desktopSlides", 3),
        tablet: readCount("tabletSlides", 2),
        mobile: readCount("mobileSlides", 1)
      };
      const autoscrollMs = readCount("autoscroll", 0);
      let slidesToShow = counts.desktop;
      let index = 0;

      const maxIndex = () => Math.max(0, slides.length - slidesToShow);
      const render = () => {
        carousel.style.setProperty("--slides-to-show", slidesToShow);
        carousel.style.setProperty("--slide-index", index);
      };
      const updateSlidesToShow = () => {
        const width = window.innerWidth;
        if (width < BREAKPOINT_MOBILE) slidesToShow = counts.mobile;
        else if (width < BREAKPOINT_TABLET) slidesToShow = counts.tablet;
        else slidesToShow = counts.desktop;
        index = Math.min(index, maxIndex());
        render();
      };
      const next = () => {
        index = index < maxIndex() ? index + 1 : 0;
        render();
      };
      const prev = () => {
        index = index > 0 ? index - 1 : maxIndex();
        render();
      };

      carousel.addEventListener("click", event => {
        const control = event.target.closest(".carousel-nav");
        if (!control) return;
        if (control.classList.contains("next")) next();
        else if (control.classList.contains("prev")) prev();
      });

      let startX = null;
      track.addEventListener(
        "touchstart",
        event => {
          startX = event.touches[0].clientX;
        },
        { passive: true }
      );
      track.addEventListener("touchend", event => {
        if (startX === null) return;
        const movedBy = event.changedTouches[0].clientX - startX;
        startX = null;
        if (movedBy < -SWIPE_THRESHOLD_PX && index < maxIndex()) next();
        else if (movedBy > SWIPE_THRESHOLD_PX && index > 0) prev();
      });

      window.addEventListener("resize", updateSlidesToShow);
      updateSlidesToShow();
      if (autoscrollMs > 0) setInterval(next, autoscrollMs);
    });
  };

  const initNewsTicker = () => {
    const list = $("#breaking-news-in-header");
    if (!list) return;
    const items = $$(".news-item", list);
    const nav = $(".breaking-news-nav", list.parentElement);
    if (items.length < 2 || !nav) return;

    const ROTATE_DELAY_MS = 5000;
    let current = Math.max(0, items.findIndex(item => item.classList.contains("is-active")));
    let timerId = null;

    const show = index => {
      items[current].classList.remove("is-active");
      current = (index + items.length) % items.length;
      items[current].classList.add("is-active");
    };
    const restartTimer = () => {
      clearInterval(timerId);
      timerId = setInterval(() => show(current + 1), ROTATE_DELAY_MS);
    };
    const step = control => {
      if (!control) return;
      show(current + (control.classList.contains("jnt-prev") ? -1 : 1));
      restartTimer();
    };

    nav.addEventListener("click", event => step(event.target.closest(".controls")));
    nav.addEventListener("keydown", event => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      step(event.target.closest(".controls"));
    });
    list.addEventListener("mouseenter", () => clearInterval(timerId));
    list.addEventListener("mouseleave", restartTimer);

    restartTimer();
  };

  const init = () => {
    renderTimes();
    initCountdown();
    initCommentForm();
    initScrollLinks();
    initStickyNav();
    initCarousels();
    initNewsTicker();
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
